
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';


	 $name =  $_POST['name'];
	 $email =   $_POST['email'];
	 $subject =   $_POST['subject'];
	 $message =   $_POST['message'];


    $mail = new PHPMailer(true);

		try {

      $messageBody = "<h2>Contact Information</h2>";
      $messageBody .= "<p>Name: $name </p>";
      $messageBody .= "<p>Email: $email </p>";
      $messageBody .= "<p>Message: $message </p>";
       

    $mail->SMTPDebug = 0;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'server238.web-hosting.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'learningdisability@teckyvate.com';                     //SMTP username
    $mail->Password   = 'LearningDisability.123#';                               //SMTP password
    $mail->SMTPSecure = "ssl";            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('learningdisability@teckyvate.com', '');
    $mail->addAddress("kayodeoluwadamilare456@yahoo.com", "Learning Disability");     //Add a recipient
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject =  $subject;
    $mail->Body    = "$messageBody";
    $mail->AltBody = '';

    $mail->send();
    echo json_encode(['status'=> true, 'message'=>'Message has been sent']) ;
} catch (Exception $e) {
	echo json_encode(['status'=> true, 'message'=>'Message could not be sent']) ;
}


?>