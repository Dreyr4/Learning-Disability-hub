/**
* PHP Email Form Validation - v3.7
* 
* 
*/
(function () {
  "use strict";

  let forms = document.querySelectorAll('.submit-btn');
  console.log(forms)

  forms.forEach( function(e) {
    e.addEventListener('click', function(event) {
         event.preventDefault();
       var formData = new FormData()
       formData.append("email",  document.getElementById("email").value)
        formData.append("name",  document.getElementById("name").value)
        formData.append("subject",  document.getElementById("subject").value)
        formData.append("message",  document.getElementById("message").value)

        document.getElementById('loading').classList.add('d-block');
        document.getElementById('error-message').classList.remove('d-block');
        document.getElementById('sent-message').classList.remove('d-block');
 
        php_email_form_submit(formData);
     
    });
  });

  function php_email_form_submit( formData) {
    fetch('forms/submission.php', {
      method: 'POST',
      body: formData,
      headers: {'X-Requested-With': 'XMLHttpRequest'}
    })
    .then((response)=>{
      if(response.ok){
        return response.json();
      }else{
        throw new Error(response.statusText)
      }
    })
    .then(data => {
      if(data.status){
        document.getElementById('loading').classList.remove('d-block');
         document.getElementById('sent-message').innerHTML = data.message;
        document.getElementById('sent-message').classList.add('d-block');
      }
      else{
        displayError(data.message);
      }
      
    })
    .catch((error) => {
      displayError( error);
    });
  }

  function displayError(error) {
   document.getElementById('loading').classList.remove('d-block');
    document.getElementById('error-message').innerHTML = error;
   document.getElementById('error-message').classList.add('d-block');

  }

})();

